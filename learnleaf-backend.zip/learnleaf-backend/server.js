
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const readData = (file) => {
  return JSON.parse(fs.readFileSync(file, 'utf-8'));
};

const writeData = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

app.get('/api/discussion', (req, res) => {
  const data = readData('discussion.json');
  res.json(data);
});

app.post('/api/discussion', (req, res) => {
  const data = readData('discussion.json');
  data.push(req.body);
  writeData('discussion.json', data);
  res.status(201).json({ message: 'Posted' });
});

app.get('/api/notes', (req, res) => {
  const data = readData('notes.json');
  res.json(data);
});

app.post('/api/notes', (req, res) => {
  const data = readData('notes.json');
  data.push(req.body);
  writeData('notes.json', data);
  res.status(201).json({ message: 'Note added' });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
